<?php
\Cloudinary::config(array( 
  "cloud_name" => "inspire-software-co", 
  "api_key" => "286472588256253", 
  "api_secret" => "QNcl4RgZ7p-6Kb1jL92NtYItkto", 
  "secure" => true
));
?>